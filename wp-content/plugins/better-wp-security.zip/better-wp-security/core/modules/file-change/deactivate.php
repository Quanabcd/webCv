<?php
ITSEC_Core::get_scheduler()->unschedule_single( 'file-change', null );
ITSEC_Core::get_scheduler()->unschedule_single( 'file-change-fast', null );