=== OT Flatsome Vertical Menu ===
Contributors: thinhbg59
Donate link: https://paypal.me/thinhbg59
Tags: flatsome, vertical menu
Requires at least: 4.0
Tested up to: 5.2.1
Stable tag: 1.2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Vertical Menu for Flatsome Woocommerce theme.
Donate link: https://paypal.me/thinhbg59
Pro version coming soon. Please follow Facebook: https://fb.com/thinh59
Thank for using.
Video setup :

[youtube http://www.youtube.com/watch?v=_k4qxWQMeoU]

== Installation ==

1. Upload contents of the plugin zip file to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Visit menu page: Menu -> Create new Menu -> Display location => Vertical Menu
4. Go Appearance -> Customize -> Header -> Header Builder , Add Vertical Menu element ( red backgroud)

== Screenshots ==


== Changelog ==
= 1.2.1 =
* Add new: Option show/hide menu in home page.
= 1.2.0 =
* Add new: Expand submenu depth.
* Add new: Overlay.
* Add new: Option show submenu.
* Fix - small css.
* Pro version coming soon. Thank for using.
= 1.1.0 =
* Add new - Menu icon, menu image.
* Add new - Menu event : Hover, Click.
* Fix - small css.
= 1.0.1 =
* Fix small issue css
= 1.0.0 =
* Initial version


== Upgrade Notice ==
