<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>

In the premium version

